package main

import (
	"encoding/pem"
	"os"
)

// writeCertificateToFile takes the certificate bytes and writes them to a specified file in PEM format.
func writeCertificateToFile(certBytes []byte, filename string) error {
	certPEMBlock := &pem.Block{
		Type:  "CERTIFICATE",
		Bytes: certBytes,
	}

	// Open a file for writing the certificate
	certFile, err := os.Create(filename)
	if err != nil {
		return err
	}
	defer certFile.Close()

	// Encode the certificate in PEM format and write to the file
	return pem.Encode(certFile, certPEMBlock)
}

func main() {
	// Example usage of writeCertificateToFile
	// Replace 'certBytes' with the actual certificate bytes obtained from CA after signing the CSR
	certBytes := []byte{} // Assume certBytes is filled with the certificate bytes

	// Replace 'client-cert.pem' with the actual path where you want to save the client certificate
	err := writeCertificateToFile(certBytes, "client-cert.pem")
	if err != nil {
		// Handle the error, for example, log it or print it out
		panic(err)
	}
}
